// Função para registrar um novo usuário
function registerUser(name, email, address, password) {
    // Verifique se o usuário já está registrado
    const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
    if (existingUsers.some(user => user.email === email)) {
        alert('Este email já está registrado.');
        return;
    }

    // Armazene o novo usuário
    const newUser = { name, email, address, password };
    existingUsers.push(newUser);
    localStorage.setItem('users', JSON.stringify(existingUsers));
    alert('Registro bem-sucedido! Faça o login agora.');
}

// Função para efetuar login
function loginUser(email, password) {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.email === email);

    if (user && user.password === password) {
        alert('Login bem-sucedido!');
    } else {
        alert('Credenciais inválidas. Tente novamente.');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Adicionar item ao carrinho quando o botão "Adicionar ao Carrinho" for clicado
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productName = button.getAttribute('data-product');
            addToCart(productName);
        });
    });

    // Registrar um novo usuário quando o botão "Registrar" for clicado
    const registerButton = document.getElementById('register-button');
    registerButton.addEventListener('click', () => {
        const name = document.getElementById('reg_name').value;
        const email = document.getElementById('reg_email').value;
        const address = document.getElementById('reg_address').value;
        const password = document.getElementById('reg_password').value;
        registerUser(name, email, address, password);
    });

    // Efetuar login quando o botão "Login" for clicado
    const loginButton = document.getElementById('login-button');
    loginButton.addEventListener('click', () => {
        const email = document.getElementById('login_email').value;
        const password = document.getElementById('login_password').value;
        loginUser(email, password);
    });
});
