document.addEventListener('DOMContentLoaded', () => {
    // Recupere os itens do carrinho do armazenamento local e exiba-os
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartList = document.getElementById('cart-items');
    
    cartItems.forEach(item => {
        const listItem = document.createElement('li');
        listItem.textContent = item;
        cartList.appendChild(listItem);
    });
});
